package com.vote.dao;



import com.vote.dao.CommonDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Ramu Maloth
 */
public class GetFingerData {

    public Connection con = null;
    public PreparedStatement ps = null;
    public ResultSet rs = null;

    public String getFingerData(String email) {
        String data = null;
        try {
             con = CommonDao.getConnection();
            String sql = "select Base64Encoded from fingertable where uid=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, email);
            rs = ps.executeQuery();
            if (rs.next()) {
                data = rs.getString(1);
            }
        } catch (Exception e) {
            System.out.println("Error At Finger " + e.getMessage());
        } finally {

            try {
                rs.close();
                ps.close();
                con.close();
            } catch (Exception e) {
            }
        }
        return data;
    }
}
