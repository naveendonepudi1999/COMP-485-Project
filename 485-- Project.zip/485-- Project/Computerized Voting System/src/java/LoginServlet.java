/*    */ import com.vote.dao.CommonDao;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.Statement;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ 
/*    */ public class LoginServlet
/*    */   extends HttpServlet
/*    */ {
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 20 */     response.setContentType("text/html");
/* 21 */     PrintWriter out = response.getWriter();
/*    */     
/* 23 */     String uid = request.getParameter("uid").trim();
/* 24 */     String pwd = request.getParameter("pwd").trim();
/* 25 */     System.out.println("in lOgin Servlet");
/* 26 */     HttpSession session = request.getSession();
/*    */     
/* 28 */     String utype = null;
/*    */     
/*    */     try {
/* 31 */       Statement stmt = CommonDao.getStatement();
/* 32 */       ResultSet rs = stmt.executeQuery("select utype From login where userid='" + uid + "' and password='" + pwd + "'");
/* 33 */       if (rs.next()) {
/*    */         
/* 35 */         utype = rs.getString(1);
/* 36 */         session.setAttribute("uid", uid);
              
/* 37 */         if (utype.equalsIgnoreCase("admin"))
/*    */         {
/* 39 */           RequestDispatcher rd = request.getRequestDispatcher("admin.jsp");
/* 40 */           rd.forward((ServletRequest)request, (ServletResponse)response);
/*    */         }
/* 42 */         else if (utype.equalsIgnoreCase("voter"))
/*    */         {
/* 44 */           RequestDispatcher rd = request.getRequestDispatcher("voter.jsp");
/* 45 */           rd.forward((ServletRequest)request, (ServletResponse)response);
/*    */         }
/* 47 */         else if (utype.equalsIgnoreCase("politician"))
/*    */         {
/* 49 */           RequestDispatcher rd = request.getRequestDispatcher("politician.jsp");
/* 50 */           rd.forward((ServletRequest)request, (ServletResponse)response);
/*    */         }
/*    */       
/*    */       } else {
/*    */         
/* 55 */         RequestDispatcher rd = request.getRequestDispatcher("login.jsp?loginStatus=false");
/* 56 */         rd.forward((ServletRequest)request, (ServletResponse)response);
/*    */       }
/*    */     
/* 59 */     } catch (Exception e) {
/* 60 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Ram\Downloads\16 Online-Voting (1)\48 Online-Voting\e- voting\WEB-INF\classes\!\LoginServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */