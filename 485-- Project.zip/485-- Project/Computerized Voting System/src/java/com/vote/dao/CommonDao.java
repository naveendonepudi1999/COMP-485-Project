/*    */ package com.vote.dao;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.Statement;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CommonDao
/*    */ {
/*    */   static Connection connection;
/*    */   static Statement statement;
/*    */   
/*    */   public static Connection getConnection() {
/*    */     try {
/* 16 */       Class.forName("com.mysql.jdbc.Driver");
/* 17 */       connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/vote", "root", "bala");
/*    */       
/* 19 */       return connection;
/*    */     }
/* 21 */     catch (Exception ex) {
/*    */       
/* 23 */       ex.printStackTrace();
/*    */       
/* 25 */       return connection;
/*    */     } 
/*    */   }
/*    */   public static Statement getStatement() {
/*    */     try {
/* 30 */       connection = getConnection();
/* 31 */       statement = connection.createStatement();
/*    */     }
/* 33 */     catch (Exception ex) {
/*    */       
/* 35 */       ex.printStackTrace();
/*    */     } 
/* 37 */     return statement;
/*    */   }
/*    */ }


/* Location:              C:\Users\Ram\Downloads\16 Online-Voting (1)\48 Online-Voting\e- voting\WEB-INF\classes\!\com\vote\dao\CommonDao.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */