/*    */ import com.vote.dao.CommonDao;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.Statement;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/*    */ 
/*    */ 
/*    */ public class RegistrationServlet
/*    */   extends HttpServlet
/*    */ {
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 21 */     response.setContentType("text/html");
/* 22 */     PrintWriter out = response.getWriter();
/*    */ 
/*    */     
/* 25 */     String name = request.getParameter("name").trim();
/* 26 */     String sname = request.getParameter("sname").trim();
/* 27 */     String age = request.getParameter("age").trim();
/* 28 */     String gender = request.getParameter("gender").trim();
/* 29 */     String pob = request.getParameter("pbirth").trim();
/* 30 */     String gname = request.getParameter("gname").trim();
/* 31 */     String hnumber = request.getParameter("hnumber").trim();
/* 32 */     String street = request.getParameter("street").trim();
/* 33 */     String town = request.getParameter("town").trim();
/* 34 */     String district = request.getParameter("district").trim();
/* 35 */     String pan = request.getParameter("pan").trim();
                String email= request.getParameter("email").trim();
/*    */ 
/*    */     
/*    */     try {
/* 39 */       int uid = 0;
/* 40 */       Connection connection = CommonDao.getConnection();
/* 41 */       Statement stmt = CommonDao.getStatement();
/* 42 */       ResultSet rs = stmt.executeQuery("select count(*) from voter");
/* 43 */       if (rs.next()) {
/* 44 */         uid = rs.getInt(1);
/*    */       }
/* 46 */       uid++;
/* 47 */       String userId = "VID000" + uid;
/* 48 */       ResultSet rs1 = stmt.executeQuery("select * from voter where uid='" + 
/* 49 */           pan + "'");
/* 50 */       if (rs1.next()) {
/*    */         
/* 52 */         response.sendRedirect("reg.jsp?regStatus=false");
/*    */       } else {
/* 54 */         PreparedStatement pstmt = connection
/* 55 */           .prepareStatement("insert into login values(?,?,?)");
/* 56 */         pstmt.setString(1, userId);
/* 57 */         pstmt.setString(2, userId);
/* 58 */         pstmt.setString(3, "voter");
/* 59 */         pstmt.executeUpdate();
/*    */         
/* 61 */         PreparedStatement pstmt1 = connection
/* 62 */           .prepareStatement("insert into voter values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
/* 63 */         pstmt1.setString(1, userId);
/* 64 */         pstmt1.setString(2, name);
/* 65 */         pstmt1.setString(3, sname);
/* 66 */         pstmt1.setInt(4, Integer.parseInt(age));
/* 67 */         pstmt1.setString(5, gender);
/* 68 */         pstmt1.setString(6, pob);
/* 69 */         pstmt1.setString(7, gname);
/* 70 */         pstmt1.setString(8, hnumber);
/* 71 */         pstmt1.setString(9, street);
/* 72 */         pstmt1.setString(10, town);
/* 73 */         pstmt1.setString(11, district);
/* 74 */         pstmt1.setString(12, pan);
                 pstmt1.setString(13, email);
/* 75 */         pstmt1.executeUpdate();
                 HttpSession session=request.getSession();
/*    */         session.setAttribute("uid",userId);
                 session.setAttribute("email",email);
/* 77 */        RequestDispatcher rd = request.getRequestDispatcher("background.jsp");
/* 79 */         rd.include((ServletRequest)request, (ServletResponse)response);
/* 80 */         out.println("<font face=georgia color=green style='position:absolute;top:180;left:40'>Registration Successful. Your Voter Id is " + 
/* 82 */             uid +".You need to login into your system with this Voter Id for polling. </font>");
        
/*    */       }
/*    */     
/* 86 */     } catch (Exception ex) {
/* 87 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Ram\Downloads\16 Online-Voting (1)\48 Online-Voting\e- voting\WEB-INF\classes\!\RegistrationServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */