/*    */ import com.vote.dao.CommonDao;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class UpdateProfile
/*    */   extends HttpServlet {
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 18 */     response.setContentType("text/html");
/* 19 */     PrintWriter out = response.getWriter();
/* 20 */     HttpSession session = request.getSession();
/* 21 */     String vid = session.getAttribute("uid").toString();
/*    */ 
/*    */     
/* 24 */     String name = request.getParameter("name").trim();
/* 25 */     String sname = request.getParameter("sname").trim();
/* 26 */     String age = request.getParameter("age").trim();
/* 27 */     String gender = request.getParameter("gender").trim();
/* 28 */     String pob = request.getParameter("pbirth").trim();
/* 29 */     String gname = request.getParameter("gname").trim();
/* 30 */     String hnumber = request.getParameter("hnumber").trim();
/* 31 */     String street = request.getParameter("street").trim();
/* 32 */     String town = request.getParameter("town").trim();
/* 33 */     String district = request.getParameter("district").trim();
/* 34 */     String pan = request.getParameter("pan").trim();
/*    */     
/*    */     try {
/* 37 */       Connection connection = CommonDao.getConnection();
/* 38 */       PreparedStatement pstmt = connection
/* 39 */         .prepareStatement("update voter set uname=?,surname=?,age=?,sex=?,pob=?,gname=?,departmentname=?,projecttilte=?,projectlead=?,developmentlocation=?,uid=? where vid=?");
/* 40 */       pstmt.setString(1, name);
/* 41 */       pstmt.setString(2, sname);
/* 42 */       pstmt.setString(3, age);
/* 43 */       pstmt.setString(4, gender);
/* 44 */       pstmt.setString(5, pob);
/* 45 */       pstmt.setString(6, gname);
/* 46 */       pstmt.setString(7, hnumber);
/* 47 */       pstmt.setString(8, street);
/* 48 */       pstmt.setString(9, town);
/* 49 */       pstmt.setString(10, district);
/* 50 */       pstmt.setString(11, pan);
/* 51 */       pstmt.setString(12, vid);
/* 52 */       pstmt.executeUpdate();
/* 53 */       RequestDispatcher rd = request.getRequestDispatcher("viewProfile.jsp?regStatus=true");
/* 54 */       rd.include((ServletRequest)request, (ServletResponse)response);
/*    */     }
/* 56 */     catch (Exception ex) {
/* 57 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Ram\Downloads\16 Online-Voting (1)\48 Online-Voting\e- voting\WEB-INF\classes\!\UpdateProfile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */