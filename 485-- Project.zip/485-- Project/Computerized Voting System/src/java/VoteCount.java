/*    */ import com.vote.dao.CommonDao;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.Statement;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class VoteCount
/*    */   extends HttpServlet
/*    */ {
/*    */   public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 19 */     response.setContentType("text/html");
/* 20 */     PrintWriter out = response.getWriter();
/* 21 */     HttpSession session = request.getSession();
/* 22 */     String vid = session.getAttribute("uid").toString();
/*    */ 
/*    */     
/* 25 */     String area = request.getParameter("area");
/* 26 */     String pname = request.getParameter("pname");
/* 27 */     String nname = request.getParameter("vcount");
/*    */     
/* 29 */     int vcount = 0;
/*    */ 
/*    */     
/*    */     try {
/* 33 */       Statement stmt = CommonDao.getStatement();
/* 34 */       Statement stmt1 = CommonDao.getStatement();
/* 35 */       ResultSet rs = stmt.executeQuery("select * from vcount where area='" + area + "' and pname='" + pname + "'");
/* 36 */       if (rs.next()) {
/*    */         
/* 38 */         vcount = rs.getInt(3);
/* 39 */         vcount++;
/* 40 */         stmt.executeUpdate("update vcount set count=" + vcount + " where area='" + area + "' and pname='" + pname + "'");
/* 41 */         stmt.executeUpdate("insert into votedvoters values('" + vid + "')");
/*    */       }
/*    */       else {
/*    */         
/* 45 */         vcount++;
/* 46 */         stmt.executeUpdate("insert into vcount values('" + area + "','" + pname + "'," + vcount + ")");
/* 47 */         stmt.executeUpdate("insert into votedvoters values('" + vid + "')");
/*    */       } 
/* 49 */       String utype = null;
/* 50 */       ResultSet rs2 = stmt1.executeQuery("select utype from login where userid like '" + vid + "'");
/* 51 */       if (rs2.next())
/*    */       {
/* 53 */         utype = rs2.getString(1);
/*    */       }
/* 55 */       if (utype.equalsIgnoreCase("voter")) {
/*    */         
/* 57 */         RequestDispatcher rd = request.getRequestDispatcher("voterBack.jsp");
/* 58 */         rd.include((ServletRequest)request, (ServletResponse)response);
/*    */       }
/* 60 */       else if (utype.equalsIgnoreCase("politician")) {
/*    */         
/* 62 */         RequestDispatcher rd = request.getRequestDispatcher("politicianBack.jsp");
/* 63 */         rd.include((ServletRequest)request, (ServletResponse)response);
/*    */       } 
/* 65 */       out.println("<div style='position: absolute;top: 190;left: 100;font-style:georgia'>");
/* 66 */       out.println("Vote Polled Successfully");
/* 67 */       out.println("</div>");
/* 68 */     } catch (Exception ex) {
/* 69 */       ex.printStackTrace();
/*    */     } 
/*    */   }
             public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
             doGet(request,response);
             }
/*    */ }


/* Location:              C:\Users\Ram\Downloads\16 Online-Voting (1)\48 Online-Voting\e- voting\WEB-INF\classes\!\VoteCount.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */