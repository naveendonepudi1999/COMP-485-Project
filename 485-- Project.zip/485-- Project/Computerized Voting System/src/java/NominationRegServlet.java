/*    */ import com.vote.dao.CommonDao;
import java.io.File;
import java.io.FileInputStream;
/*    */ import java.io.IOException;
import java.io.InputStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.Statement;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ public class NominationRegServlet
/*    */   extends HttpServlet
/*    */ {
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 21 */     response.setContentType("text/html");
/* 22 */     PrintWriter out = response.getWriter();
/*    */ 
/*    */     
/* 25 */     String nname = request.getParameter("nname").trim();
/* 26 */     
/* 27 */     String pname = request.getParameter("pname").trim();
/* 28 */     String area = request.getParameter("area").trim();
/*    */      File image = new File("C:/Gallery/"+request.getParameter("plogo").trim());
/*    */     
/*    */     try {
/* 32 */       Connection connection = CommonDao.getConnection();
/* 33 */       Statement stmt = connection.createStatement();
/* 35 */       ResultSet rs = stmt.executeQuery("select * From nomination where softwaremodel='" +nname+"' and sdlname='"+pname+"'");
/* 37 */       if (rs.next()) {RequestDispatcher rd = request
/* 64 */           .getRequestDispatcher("adminBack.jsp");
/* 65 */         rd.include((ServletRequest)request, (ServletResponse)response);
/* 66 */         out
/* 67 */           .println("<br/><br/><br/><br/><br/><br/><br/><font color=red size=4><center>The Given Software Development Language Details Exists............</center</font>");
/*    */       
/* 38 */        }else{
                   FileInputStream fis;
/* 48 */           PreparedStatement pstmt = connection.prepareStatement("insert into nomination values(?,?,?,?)");
/* 50 */           pstmt.setString(1, nname);
/* 52 */           pstmt.setString(2, pname);
/* 53 */           pstmt.setString(3, area);
                   fis = new FileInputStream(image);
                   pstmt.setBinaryStream(4, (InputStream)fis, (int)(image.length()));
/* 54 */           pstmt.executeUpdate();
/* 55 */           RequestDispatcher rd = request.getRequestDispatcher("adminBack.jsp");
/* 58 */           rd.include((ServletRequest)request, (ServletResponse)response);
/* 59 */           out.println("<br/><br/><br/><br/><br/><br/><br/><font color=green size=4><center>Nomination drawn successfully.......</center></font>");
/*    */         } 
/*    */        
/* 69 */     } catch (Exception e) {
/* 70 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }

