/*    */ import com.vote.dao.CommonDao;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Statement;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ 
/*    */ public class PostCommentServlet
/*    */   extends HttpServlet
/*    */ {
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 18 */     response.setContentType("text/html");
/* 19 */     PrintWriter out = response.getWriter();
/*    */ 
/*    */     
/* 22 */     String uname = request.getParameter("uname").trim();
/* 23 */     String comment = request.getParameter("comment").trim();
/*    */ 
/*    */     
/*    */     try {
/* 27 */       Statement stmt = CommonDao.getStatement();
/* 28 */       stmt.executeUpdate("insert into comments values('" + uname + "','" + comment + "')");
/* 29 */       RequestDispatcher rd = request.getRequestDispatcher("contactus.jsp?cstatus=true");
/* 30 */       rd.include((ServletRequest)request, (ServletResponse)response);
/*    */     
/*    */     }
/* 33 */     catch (Exception ex) {
/* 34 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Ram\Downloads\16 Online-Voting (1)\48 Online-Voting\e- voting\WEB-INF\classes\!\PostCommentServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */