/*    */ import com.vote.dao.CommonDao;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class EScheduleServlet
/*    */   extends HttpServlet {
/*    */   public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 17 */     response.setContentType("text/html");
/* 18 */     PrintWriter out = response.getWriter();
/*    */ 
/*    */     
/* 21 */     String stype = request.getParameter("stype").trim();
/* 22 */     String fdate = request.getParameter("fdate").trim();
/* 23 */     String tdate = request.getParameter("tdate").trim();
/*    */ 
/*    */     
/*    */     try {
/* 27 */       Connection connection = CommonDao.getConnection();
/* 28 */       PreparedStatement pstmt = connection
/* 29 */         .prepareStatement("insert into eschedule values(?,?,?)");
/* 30 */       pstmt.setString(1, stype);
/* 31 */       pstmt.setString(2, fdate);
/* 32 */       pstmt.setString(3, tdate);
/* 33 */       pstmt.executeUpdate();
/* 34 */       RequestDispatcher rd = request
/* 35 */         .getRequestDispatcher("adminBack.jsp");
/* 36 */       rd.include((ServletRequest)request, (ServletResponse)response);
/* 37 */       out
/* 38 */         .println("<br/><br/><br/><br/><br/><br/><br/><font color=green size=4><center>Schedule Fixed Successfully..........</center></font>");
/* 39 */     } catch (Exception ex) {
/* 40 */       ex.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Ram\Downloads\16 Online-Voting (1)\48 Online-Voting\e- voting\WEB-INF\classes\!\EScheduleServlet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */